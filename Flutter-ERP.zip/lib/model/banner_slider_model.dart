class BannerSliderModel {
  late int id;
  String? name;
  late String image;

  BannerSliderModel({required this.id, this.name, required this.image});
}