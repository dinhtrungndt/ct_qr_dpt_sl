class VisitTodayModel {
  late int id;
  late String name;
  late String address;
  late String phone;
  late String line;
  VisitTodayModel({required this.id, required this.name, required this.address,required this.phone,required this.line});
}