class SiteModel{
  final int id;
  final String code;
  final String name;
  SiteModel({required this.id,required this.code, required this.name});
}