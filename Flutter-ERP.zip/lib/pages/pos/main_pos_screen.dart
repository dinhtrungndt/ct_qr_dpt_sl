import 'package:flutter/material.dart';

class MainPosScreen extends StatelessWidget {
  const MainPosScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(child: Text('Pos'),);
  }
}