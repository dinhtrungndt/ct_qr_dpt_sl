part of 'overtime_bloc.dart';

abstract class OvertimeState extends Equatable {
  const OvertimeState();

  @override
  List<Object> get props => [];
}

class OvertimeInitial extends OvertimeState {}
