part of 'overtime_bloc.dart';

abstract class OvertimeEvent extends Equatable {
  const OvertimeEvent();

  @override
  List<Object> get props => [];
}
