package com.example.erp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
